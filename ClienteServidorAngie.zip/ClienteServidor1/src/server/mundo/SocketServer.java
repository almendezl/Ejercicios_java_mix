package server.mundo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.naming.directory.DirContext;
import javax.swing.JOptionPane;

import complementos.Conexiondb;
import complementos.PlainText;
import complementos.Transaction;
import server.controlador.Controlador;

public class SocketServer implements Runnable {

	// atributos
	private Controlador ctrl;
	private static PlainText dir;
	private Transaction trans;
	private Conexiondb db;
	private int row;
	private String query;
	// constantes
	private final int ZON = 2400;
	private final int COM = 2200;

	public SocketServer(Controlador ctrl) {
		this.ctrl = ctrl;
		Thread treadListener = new Thread(this);
		treadListener.start();
		dir = new PlainText(); // leer el txt
	}

	/* Server:Data >> Socket >> Client */
	public static void socket(String msg) {
		try {
			Socket server = new Socket(dir.getClient(), 5050); // portSend 5050
			DataOutputStream outBuffer = new DataOutputStream(server.getOutputStream());
			outBuffer.writeUTF(msg);
			server.close();
		} catch (UnknownHostException e) {
			JOptionPane.showMessageDialog(null, "Server : socket() : UnknownHostException: " + e.getMessage());
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Server : socket() : IOException: " + e.getMessage());
		}
	}

	@Override
	/* Server: Listen */
	public void run() {
		ServerSocket serverSocket;
		Socket socket;
		DataInputStream inDataBuffer; // recibir string
		ObjectInputStream inObBuffer; // recibir objeto

		try {
			serverSocket = new ServerSocket(5000); // portListen 5000

			while (true) {
				socket = serverSocket.accept();
				inDataBuffer = new DataInputStream(socket.getInputStream()); // datos
				inObBuffer = new ObjectInputStream(socket.getInputStream()); // objetos
				String ip = inDataBuffer.readUTF();
				String msg = inDataBuffer.readUTF();

				Object myObject = inObBuffer.readObject();
				trans = (Transaction) myObject;

				if (msg.equals("0")) {
					recargar();
					response("Recarga exitosa");
				} else if (msg.equals("1")) {

				} else if (msg.equals("2")) {
					pagar(0); // para pago zonal
				} else if (msg.equals("3")) {
					pagar(1); // para pago complementario
				} else {
					socket.close();
				}
			}

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Server : run (): IOException: " + e.getMessage());
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public static void response(String msg) {
		socket(msg);
	}

	public void recargar() {
		db = new Conexiondb();

		query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
				+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , "
				+ trans.getValor() + " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + trans.getBalance()
				+ " )";
		db.setValues(query);
		ctrl.actPnlTr(trans.getId());
	}

	public boolean comPag(int pago) {
		if (trans.getBalance() - pago >= 0) {// pago normal porque le alcanza
			return true;
		} else if ((Integer.parseInt((String) ctrl.obtValueTab(row - 1, 4)) < 0
				&& Integer.parseInt((String) ctrl.obtValueTab(row - 2, 4)) < 0)
				|| Integer.parseInt((String) ctrl.obtValueTab(row - 2, 4)) < 0) { // si se le ha prestado dos veces
			response("Saldo insuficiente, recargue el saldo pendiente mas el valor del tickete.!");
			return false;
		} else if (Integer.parseInt((String) ctrl.obtValueTab(row - 1, 4)) < 0 || trans.getBalance() - pago < 0) {
			// si no se le ha prestado o se le ha prestado una vez
			return true;
		}
		return false;
	}

	public void pagar(int op) {

		row = ctrl.obtRow();
		query = "";

		if (op == 0) {// ZONAL
			if (ctrl.obtValueTab(row - 1, 0).equals("C") && comPag(ZON - COM)) { // si se toma despues de haber usado
																					// SITP cobra 200
				query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
						+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , "
						+ (ZON - COM) + " , '" + trans.getFecha() + "', '" + trans.getHora() + "',"
						+ (trans.getBalance() - (ZON - COM)) + " )";
				response("p1");
				sendDataDB();
			} else if (comPag(ZON)) { // si se toma sin haber tomado el sitp descuenta 2400
				query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
						+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , " + ZON
						+ " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + (trans.getBalance() - ZON)
						+ " )";
				response("p2");
				sendDataDB();
			}
		} else if (op == 1) {// SITP
			if (ctrl.obtValueTab(row - 1, 0).equals("Z") && comPag(0)) {// si se toma despues de haber tomado zonal
																		// descuenta 0
				query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
						+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , " + 0
						+ " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + trans.getBalance() + " )";
				response("p3");
				sendDataDB();
			} else {
				if (ctrl.obtValueTab(row - 1, 0).equals("C") && ctrl.obtValueTab(row - 2, 0).equals("C")
						&& comPag(COM)) { // la tercera vez si cobra
					query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
							+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , " + COM
							+ " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + (trans.getBalance() - COM)
							+ " )";
					response("p4");
					sendDataDB();
				} else if (ctrl.obtValueTab(row - 1, 0).equals("C") && comPag(0)) {// la segunda vez no cobra
					query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
							+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , " + 0
							+ " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + trans.getBalance() + " )";
					response("p5");
					sendDataDB();
				} else if (comPag(COM)) {// si no ha tomado ni zonal ni sitp
					query = "INSERT INTO transactions (idCard, id, TransactionType, vlrTransaction, date , time, balance) VALUES ("
							+ "'" + trans.getIdCard() + "', '" + trans.getId() + "', '" + trans.getTipo() + "' , " + COM
							+ " , '" + trans.getFecha() + "', '" + trans.getHora() + "'," + (trans.getBalance() - COM)
							+ " )";
					response("p6");
					sendDataDB();
				}

			}
		}

	}

	public void sendDataDB() {
		db = new Conexiondb();
		db.setValues(query);
		ctrl.actPnlTr(trans.getId());
	}
}
